import { describe, it, expect } from "vitest";
import { parseTimeValue, compareTime } from "../src/time-sort";

describe("parseTimeValue", () => {
  it("accepts numbers and numeric strings", () => {
    expect(parseTimeValue(3)).toBe(3);
    expect(parseTimeValue("2")).toBe(2);
    expect(parseTimeValue(" 4 ")).toBe(4);
    expect(parseTimeValue("1,5")).toBe(1.5);
  });

  it("returns null for empty or non-numeric values", () => {
    expect(parseTimeValue(undefined)).toBeNull();
    expect(parseTimeValue(null)).toBeNull();
    expect(parseTimeValue("")).toBeNull();
    expect(parseTimeValue("mucho")).toBeNull();
    expect(parseTimeValue(Number.NaN)).toBeNull();
    expect(parseTimeValue(["1"])).toBeNull();
  });
});

describe("compareTime", () => {
  const sortWith = (vals: (number | null)[], asc: boolean) =>
    [...vals].sort((a, b) => compareTime(a, b, asc));

  it("sorts shortest first and puts missing values last", () => {
    expect(sortWith([3, null, 1, 5, 2], true)).toEqual([1, 2, 3, 5, null]);
  });

  it("sorts longest first and still puts missing values last", () => {
    expect(sortWith([3, null, 1, 5, 2], false)).toEqual([5, 3, 2, 1, null]);
  });

  it("treats equal values as ties", () => {
    expect(compareTime(2, 2, true)).toBe(0);
    expect(compareTime(null, null, false)).toBe(0);
  });
});
