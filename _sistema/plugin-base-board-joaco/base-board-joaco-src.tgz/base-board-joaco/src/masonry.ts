// Joaco fork: mosaic layout for double columns. The cards container is a
// two-column CSS grid with 1px rows; each card spans as many rows as its
// height, so every card sits right under the previous one in the shorter half
// and no vertical gaps are left. A ResizeObserver keeps the spans in sync when
// a card grows or shrinks (subtasks checked, text edited, width changes).

import { MASONRY_GAP, masonrySpan } from "./two-col";

export const DOUBLE_COLUMN_CLASS = "base-board-column--double";

/** True when the cards container belongs to a column shown in two halves. */
export function isInDoubleColumn(cardsEl: HTMLElement | null): boolean {
  return !!cardsEl?.parentElement?.classList.contains(DOUBLE_COLUMN_CLASS);
}

/** Vertical gap of the container (its column gap), or the default. */
function gapOf(cardsEl: HTMLElement): number {
  const raw = parseFloat(window.getComputedStyle(cardsEl).columnGap);
  return Number.isFinite(raw) && raw >= 0 ? raw : MASONRY_GAP;
}

/** Set (or clear) the row span of one item according to its container. */
export function syncMasonryItem(el: HTMLElement): void {
  const cardsEl = el.parentElement;
  if (!cardsEl || !isInDoubleColumn(cardsEl)) {
    el.style.removeProperty("grid-row-end");
    return;
  }
  const height = el.getBoundingClientRect().height;
  el.style.setProperty(
    "grid-row-end",
    `span ${masonrySpan(height, gapOf(cardsEl))}`,
  );
}

export class MasonryLayout {
  private observer: ResizeObserver | null = null;

  private getObserver(): ResizeObserver {
    if (!this.observer) {
      this.observer = new ResizeObserver((entries) => {
        for (const entry of entries) {
          if (entry.target.instanceOf(HTMLElement)) {
            syncMasonryItem(entry.target);
          }
        }
      });
    }
    return this.observer;
  }

  /** Lay out the cards of a column (or undo the layout if not double). */
  public apply(cardsEl: HTMLElement): void {
    const isDouble = isInDoubleColumn(cardsEl);
    for (const child of Array.from(cardsEl.children)) {
      if (!child.instanceOf(HTMLElement)) continue;
      if (isDouble) {
        this.getObserver().observe(child);
      } else {
        this.observer?.unobserve(child);
      }
      syncMasonryItem(child);
    }
  }

  public destroy(): void {
    this.observer?.disconnect();
    this.observer = null;
  }
}
