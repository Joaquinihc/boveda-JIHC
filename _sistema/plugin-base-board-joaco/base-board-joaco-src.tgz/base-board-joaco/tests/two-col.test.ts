import { describe, it, expect } from "vitest";
import {
  parseColumnList,
  isDoubleColumn,
  masonryInsertIndex,
  masonrySpan,
  type CardBox,
} from "../src/two-col";

describe("parseColumnList", () => {
  it("splits, trims and lower-cases", () => {
    expect(parseColumnList(" En-Curso , pendiente,,")).toEqual([
      "en-curso",
      "pendiente",
    ]);
  });
  it("returns [] for non-strings or empty text", () => {
    expect(parseColumnList(undefined)).toEqual([]);
    expect(parseColumnList(3)).toEqual([]);
    expect(parseColumnList("  ")).toEqual([]);
  });
});

describe("isDoubleColumn", () => {
  const cols = ["en-curso"];
  it("only for configured columns above the threshold", () => {
    expect(isDoubleColumn("en-curso", 11, cols, 10)).toBe(true);
    expect(isDoubleColumn("En-Curso", 17, cols, 10)).toBe(true);
    expect(isDoubleColumn("en-curso", 10, cols, 10)).toBe(false);
    expect(isDoubleColumn("pendiente", 30, cols, 10)).toBe(false);
    expect(isDoubleColumn("en-curso", 30, [], 10)).toBe(false);
  });
});

describe("masonrySpan", () => {
  it("height plus gap, rounded up", () => {
    expect(masonrySpan(100, 6)).toBe(106);
    expect(masonrySpan(100.2, 6)).toBe(107);
    expect(masonrySpan(0, 6)).toBe(6);
    expect(masonrySpan(Number.NaN, 6)).toBe(6);
    expect(masonrySpan(0, 0)).toBe(1);
  });
});

// Mosaic: left half 0–100, right half 110–210, cards in DOM order.
//  0 L   0– 50     1 R   0–150
//  2 L  56–120     3 L 126–160     4 R 156–200
const boxes: CardBox[] = [
  { top: 0, bottom: 50, left: 0, right: 100 },
  { top: 0, bottom: 150, left: 110, right: 210 },
  { top: 56, bottom: 120, left: 0, right: 100 },
  { top: 126, bottom: 160, left: 0, right: 100 },
  { top: 156, bottom: 200, left: 110, right: 210 },
];

describe("masonryInsertIndex", () => {
  it("before the first card of the half whose center is below the cursor", () => {
    expect(masonryInsertIndex(boxes, 20, 10)).toBe(0);
    expect(masonryInsertIndex(boxes, 20, 40)).toBe(2);
    expect(masonryInsertIndex(boxes, 20, 100)).toBe(3);
    expect(masonryInsertIndex(boxes, 150, 60)).toBe(1);
    expect(masonryInsertIndex(boxes, 150, 100)).toBe(4);
  });
  it("after the last card of the half: before the next card in DOM order", () => {
    expect(masonryInsertIndex(boxes, 20, 155)).toBe(4);
    expect(masonryInsertIndex(boxes, 150, 190)).toBe(-1);
  });
  it("cursor between halves picks the nearest", () => {
    expect(masonryInsertIndex(boxes, 104, 10)).toBe(0);
    expect(masonryInsertIndex(boxes, 107, 10)).toBe(1);
  });
  it("empty container appends", () => {
    expect(masonryInsertIndex([], 20, 20)).toBe(-1);
  });
});
