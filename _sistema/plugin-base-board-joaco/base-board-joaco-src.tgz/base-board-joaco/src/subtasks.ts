import { App, TFile } from "obsidian";

/** One checkbox line inside the subtasks section of a note. */
export interface Subtask {
  text: string;
  done: boolean;
  /** Line number (0-based) inside the file at parse time. */
  lineNo: number;
}

const CHECKBOX_RE = /^(\s*[-*+]\s+\[)( |x|X)(\]\s*)(.*)$/;
const HEADING_RE = /^#{1,6}\s/;

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Extract the checkbox items under the given heading (any level).
 * The section ends at the next heading of any level or at EOF.
 * Items with empty text (e.g. a template's bare "- [ ]") are skipped.
 */
export function parseSubtasks(content: string, heading: string): Subtask[] {
  const headingRe = new RegExp(
    `^#{1,6}\\s+${escapeRegex(heading.trim())}\\s*$`,
    "i",
  );
  const lines = content.split("\n");
  const out: Subtask[] = [];
  let inSection = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (HEADING_RE.test(line)) {
      inSection = headingRe.test(line);
      continue;
    }
    if (!inSection) continue;
    const m = line.match(CHECKBOX_RE);
    if (m) {
      const text = m[4].trim();
      if (text) out.push({ text, done: m[2] !== " ", lineNo: i });
    }
  }
  return out;
}

/**
 * Toggle a checkbox in the file. Primary match is by line number + text;
 * if the file changed since parse time, fall back to the first checkbox in
 * the section whose text and done-state match the snapshot.
 */
export async function toggleSubtask(
  app: App,
  file: TFile,
  heading: string,
  task: Subtask,
): Promise<boolean> {
  let toggled = false;
  await app.vault.process(file, (data) => {
    const lines = data.split("\n");

    const flip = (lineNo: number): boolean => {
      const m = lines[lineNo]?.match(CHECKBOX_RE);
      if (!m) return false;
      const newMark = m[2] === " " ? "x" : " ";
      lines[lineNo] = `${m[1]}${newMark}${m[3]}${m[4]}`;
      return true;
    };

    // 1. Exact position + text still matches
    const at = lines[task.lineNo]?.match(CHECKBOX_RE);
    if (at && at[4].trim() === task.text && (at[2] !== " ") === task.done) {
      toggled = flip(task.lineNo);
    } else {
      // 2. Fallback: re-parse and match by text + state
      const fresh = parseSubtasks(lines.join("\n"), heading);
      const candidate = fresh.find(
        (t) => t.text === task.text && t.done === task.done,
      );
      if (candidate) toggled = flip(candidate.lineNo);
    }

    return lines.join("\n");
  });
  return toggled;
}
