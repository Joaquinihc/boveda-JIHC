/** Column label used when an entry has no value for the groupBy property. */
export const NO_VALUE_COLUMN = "(No value)";

/** Frontmatter property that controls card ordering within a column. */
export const ORDER_PROPERTY = "kanban_order";

/** Key used by BasesViewConfig.set/get to persist column order in the .base file. */
export const CONFIG_KEY_COLUMNS = "boardColumns";

/** Key used by BasesViewConfig.set/get to persist collapsed column state. */
export const CONFIG_KEY_COLLAPSED_COLUMNS = "collapsedColumns";

/** Key used by BasesViewConfig.set/get to persist custom tag colors in the .base file. */
export const CONFIG_KEY_TAG_COLORS = "tagColors";

/** Key used by BasesViewConfig.set/get to persist card click behavior in the .base file. */
export const CONFIG_KEY_OPEN_BEHAVIOR = "cardOpenBehavior";

/** Key used by BasesViewConfig.set/get to persist column colors in the .base file. */
export const CONFIG_KEY_COLUMN_COLORS = "columnColors";

/** Key used by BasesViewConfig.set/get to persist per-column WIP limits. */
export const CONFIG_KEY_WIP_LIMITS = "wipLimits";

/** Key used by BasesViewConfig.set/get to persist card cover property key in the .base file. */
export const CONFIG_KEY_COVER_PROPERTY = "cardCoverProperty";

/** Key used by BasesViewConfig.set/get to persist if new cards should be added to the top in the .base file. */
export const CONFIG_KEY_ADD_TO_TOP = "newCardsToTop";

// ---------------------------------------------------------------------------
//  Config keys added by the Joaco fork
// ---------------------------------------------------------------------------

/** Toggle: render subtask checkboxes on cards. */
export const CONFIG_KEY_SHOW_SUBTASKS = "showSubtasks";

/** Heading of the note section that holds the subtasks (e.g. "Subtareas"). */
export const CONFIG_KEY_SUBTASKS_HEADING = "subtasksHeading";

/** Max number of subtasks shown on a card before the "+N más" toggle. */
export const CONFIG_KEY_SUBTASKS_VISIBLE = "subtasksVisible";

/** Property (BasesPropertyId) that holds the priority, e.g. "note.prioridad". */
export const CONFIG_KEY_PRIORITY_PROPERTY = "priorityProperty";

/** Record<value, cssColor> with custom colors per priority value. */
export const CONFIG_KEY_PRIORITY_COLORS = "priorityColors";

/** Comma-separated value ranking used to sort cards, e.g. "alta, media, baja". */
export const CONFIG_KEY_PRIORITY_ORDER = "priorityOrder";

/** Toggle: sort cards inside each column by the priority ranking. */
export const CONFIG_KEY_SORT_BY_PRIORITY = "sortByPriority";

/** Default ranking of priority values (highest first). */
export const DEFAULT_PRIORITY_ORDER =
  "alta, media-alta, media, media-baja, baja";

/** Property (BasesPropertyId) with the estimated time (numeric scale), e.g. "note.tiempo". */
export const CONFIG_KEY_TIME_PROPERTY = "timeProperty";

/** Toggle: inside the same priority, sort cards by the estimated time. */
export const CONFIG_KEY_SORT_BY_TIME = "sortByTime";

/** Toggle: shortest tasks first (true) or longest first (false). */
export const CONFIG_KEY_TIME_ASCENDING = "timeAscending";

/** Toggle: show the board-wide sequence number (1, 2, 3…) on each card. */
export const CONFIG_KEY_SHOW_SEQUENCE = "showSequence";

/** Comma-separated column order used to number the cards across the board. */
export const CONFIG_KEY_SEQUENCE_COLUMNS = "sequenceColumns";

/** Default numbering order of the columns (first column gets 1). */
export const DEFAULT_SEQUENCE_COLUMNS =
  "en-revision, en-curso, pendiente, bloqueada, propuesta";

/** Toggle: show the task id in the card footer. */
export const CONFIG_KEY_SHOW_ID = "showTaskId";

/** Property (BasesPropertyId) holding the stable task id, e.g. "note.id". */
export const CONFIG_KEY_ID_PROPERTY = "taskIdProperty";

/** Toggle: show the permanent property filter bar. */
export const CONFIG_KEY_SHOW_FILTER_BAR = "showFilterBar";

/** Property (BasesPropertyId) rendered as a permanent filter bar, e.g. "note.tipo". */
export const CONFIG_KEY_FILTER_BAR_PROPERTY = "filterBarProperty";

/** Persisted selection of the property filter bar (string[]). */
export const CONFIG_KEY_FILTER_BAR_SELECTED = "filterBarSelected";

/** Toggle: show the last-modified date at the bottom of each card. */
export const CONFIG_KEY_SHOW_MODIFIED = "showModified";

/** Built-in fallback colors for common priority values. */
export const DEFAULT_PRIORITY_COLORS: Record<string, string> = {
  alta: "#e93147",
  "media-alta": "#ec7a08",
  media: "#e0ac00",
  "media-baja": "#8fb31a",
  baja: "#08b94e",
};

/**
 * Regex matching characters that are invalid in file/folder names.
 * Used when sanitizing user input before creating vault items.
 */
export const UNSAFE_FILENAME_CHARS = /[\\/:*?"<>|]/g;

/**
 * Sanitize a string for use as a file or folder name by stripping
 * characters that are not allowed on common operating systems.
 */
export function sanitizeFilename(name: string): string {
  return name.replace(UNSAFE_FILENAME_CHARS, "");
}
