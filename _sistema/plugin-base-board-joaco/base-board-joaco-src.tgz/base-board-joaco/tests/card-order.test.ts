import { describe, it, expect } from "vitest";
import { renameOrderKeys, deleteOrderKey, OrderMap } from "../src/card-order";

describe("renameOrderKeys", () => {
  it("moves the key of a renamed file", () => {
    const m: OrderMap = { "Tareas/A.md": "a0", "Tareas/B.md": "a1" };
    expect(renameOrderKeys(m, "Tareas/A.md", "Tareas/A2.md", false)).toBe(true);
    expect(m).toEqual({ "Tareas/A2.md": "a0", "Tareas/B.md": "a1" });
  });

  it("is a no-op for files without an entry", () => {
    const m: OrderMap = { "Tareas/B.md": "a1" };
    expect(renameOrderKeys(m, "Tareas/X.md", "Tareas/Y.md", false)).toBe(false);
    expect(m).toEqual({ "Tareas/B.md": "a1" });
  });

  it("re-prefixes every key under a renamed folder", () => {
    const m: OrderMap = { "Tareas/A.md": "a0", "Tareas/sub/B.md": "a1", "Otra/C.md": "a2" };
    expect(renameOrderKeys(m, "Tareas", "Trabajo", true)).toBe(true);
    expect(m).toEqual({ "Trabajo/A.md": "a0", "Trabajo/sub/B.md": "a1", "Otra/C.md": "a2" });
  });

  it("does not touch sibling folders sharing a prefix", () => {
    const m: OrderMap = { "Tareas2/A.md": "a0" };
    expect(renameOrderKeys(m, "Tareas", "Trabajo", true)).toBe(false);
    expect(m).toEqual({ "Tareas2/A.md": "a0" });
  });
});

describe("deleteOrderKey", () => {
  it("removes the entry of a deleted file", () => {
    const m: OrderMap = { "Tareas/A.md": "a0" };
    expect(deleteOrderKey(m, "Tareas/A.md")).toBe(true);
    expect(m).toEqual({});
    expect(deleteOrderKey(m, "Tareas/A.md")).toBe(false);
  });
});
