import {
  Plugin,
  Platform,
  Notice,
  QueryController,
  TFile,
  TFolder,
  TAbstractFile,
} from "obsidian";
import { KanbanView } from "./kanban-view";
import { sanitizeFilename } from "./constants";
import { CreateBoardModal, BoardConfig } from "./modals";
import { updateBaseFolderReferences } from "./folder-rename";
import { OrderMap, renameOrderKeys, deleteOrderKey } from "./card-order";
import {
  parseTaskId,
  planIdAssignments,
  normalizeDate,
  IdCandidate,
} from "./task-id";

/** Per-base column configuration */
export interface ColumnConfig {
  columns: string[];
}

/** Joaco fork: automatic, stable task ids (e.g. "T-042"). */
export interface TaskIdSettings {
  enabled: boolean;
  /** Only notes inside this folder (and subfolders) get an id. */
  folder: string;
  /** Frontmatter property + value that mark a note as a task. */
  typeProperty: string;
  typeValue: string;
  /** Frontmatter property that stores the id. */
  idProperty: string;
  prefix: string;
  pad: number;
  /** Frontmatter date used to order new ids (YYYY-MM-DD). */
  dateProperty: string;
  /**
   * Only assign ids on the desktop app. When the vault is synced to a phone
   * (e.g. with Git), two devices assigning at once could reuse a number.
   */
  desktopOnly: boolean;
}

export interface PluginData {
  columnConfigs: Record<string, ColumnConfig>;
  /** Joaco fork: manual card order per board, keyed by file path. */
  cardOrders: Record<string, OrderMap>;
  /** Joaco fork: task id assignment settings. */
  taskIds: TaskIdSettings;
}

const DEFAULT_TASK_IDS: TaskIdSettings = {
  enabled: true,
  folder: "Tareas",
  typeProperty: "type",
  typeValue: "tarea",
  idProperty: "id",
  prefix: "T-",
  pad: 3,
  dateProperty: "creado",
  desktopOnly: true,
};

const DEFAULT_DATA: PluginData = {
  columnConfigs: {},
  cardOrders: {},
  taskIds: DEFAULT_TASK_IDS,
};

// ---------------------------------------------------------------------------
//  Plugin
// ---------------------------------------------------------------------------

export default class BaseBoardPlugin extends Plugin {
  data_: PluginData = DEFAULT_DATA;

  /** Folder rename mappings collected during one rename burst, pending flush. */
  private pendingFolderRenames: Array<{ oldPath: string; newPath: string }> =
    [];
  /** Debounce timer that flushes pendingFolderRenames once the burst settles. */
  private folderRenameFlushTimer: number | null = null;
  /** Joaco fork: debounce timer and guard for the task id assigner. */
  private taskIdTimer: number | null = null;
  private assigningTaskIds = false;

  async onload() {
    await this.loadPluginData();

    this.registerBasesView("kanban", {
      name: "Kanban",
      icon: "lucide-kanban",
      factory: (controller: QueryController, containerEl: HTMLElement) =>
        new KanbanView(controller, containerEl, this),
      options: () => KanbanView.getViewOptions(),
    });

    // -- Command: Create new board --------------------------------------------
    this.addCommand({
      id: "create-board",
      name: "Create new board",
      callback: () => {
        new CreateBoardModal(this.app, (config) => {
          void this.createBoard(config);
        }).open();
      },
    });

    // -- Keep board filters in sync when their folder is renamed/moved --------
    this.registerEvent(
      this.app.vault.on("rename", (file, oldPath) => {
        this.handleFolderRename(file, oldPath);
        this.handleCardOrderRename(file, oldPath);
      }),
    );

    // -- Joaco fork: keep manual card order when notes are deleted ------------
    this.registerEvent(
      this.app.vault.on("delete", (file) => {
        if (!(file instanceof TFile)) return;
        let changed = false;
        for (const baseId of Object.keys(this.data_.cardOrders)) {
          const map = this.data_.cardOrders[baseId];
          if (deleteOrderKey(map, file.path)) changed = true;
        }
        if (changed) void this.savePluginData();
      }),
    );

    // -- Joaco fork: give every task a stable id ------------------------------
    this.app.workspace.onLayoutReady(() => {
      this.scheduleTaskIdAssignment();
      this.registerEvent(
        this.app.metadataCache.on("changed", (file, _data, cache) => {
          if (this.isTaskWithoutId(file, cache?.frontmatter)) {
            this.scheduleTaskIdAssignment();
          }
        }),
      );
    });
  }

  onunload() {
    if (this.folderRenameFlushTimer !== null) {
      window.clearTimeout(this.folderRenameFlushTimer);
    }
    if (this.taskIdTimer !== null) {
      window.clearTimeout(this.taskIdTimer);
    }
  }

  // -- Task ids (Joaco fork) --------------------------------------------------

  private inTaskFolder(file: TFile): boolean {
    const folder = this.data_.taskIds.folder.replace(/\/+$/, "");
    return folder === "" || file.path.startsWith(folder + "/");
  }

  private isTask(
    file: TFile,
    fm: Record<string, unknown> | undefined,
  ): boolean {
    const cfg = this.data_.taskIds;
    return (
      cfg.enabled &&
      file.extension === "md" &&
      this.inTaskFolder(file) &&
      !!fm &&
      fm[cfg.typeProperty] === cfg.typeValue
    );
  }

  private isTaskWithoutId(
    file: TFile,
    fm: Record<string, unknown> | undefined,
  ): boolean {
    const cfg = this.data_.taskIds;
    return (
      this.isTask(file, fm) &&
      parseTaskId(fm?.[cfg.idProperty], cfg.prefix) === null
    );
  }

  private scheduleTaskIdAssignment(): void {
    if (!this.data_.taskIds.enabled) return;
    if (this.data_.taskIds.desktopOnly && Platform.isMobile) return;
    if (this.taskIdTimer !== null) window.clearTimeout(this.taskIdTimer);
    this.taskIdTimer = window.setTimeout(() => {
      this.taskIdTimer = null;
      void this.assignMissingTaskIds();
    }, 1500);
  }

  /**
   * Give an id (max + 1, oldest date first) to every task that has none.
   * Existing ids are never changed or reused.
   */
  private async assignMissingTaskIds(): Promise<void> {
    if (this.assigningTaskIds) {
      this.scheduleTaskIdAssignment();
      return;
    }
    this.assigningTaskIds = true;
    try {
      const cfg = this.data_.taskIds;
      const existing: number[] = [];
      const candidates: IdCandidate[] = [];
      for (const file of this.app.vault.getMarkdownFiles()) {
        const fm = this.app.metadataCache.getFileCache(file)?.frontmatter;
        if (!this.isTask(file, fm)) continue;
        const n = parseTaskId(fm?.[cfg.idProperty], cfg.prefix);
        if (n !== null) {
          existing.push(n);
        } else {
          candidates.push({
            path: file.path,
            creado: normalizeDate(fm?.[cfg.dateProperty]),
            ctime: file.stat.ctime,
          });
        }
      }
      if (candidates.length === 0) return;
      const plan = planIdAssignments(existing, candidates, cfg.prefix, cfg.pad);
      for (const { path, id } of plan) {
        const file = this.app.vault.getAbstractFileByPath(path);
        if (!(file instanceof TFile)) continue;
        await this.app.fileManager.processFrontMatter(
          file,
          (fm: Record<string, unknown>) => {
            if (parseTaskId(fm[cfg.idProperty], cfg.prefix) === null) {
              fm[cfg.idProperty] = id;
            }
          },
        );
      }
    } catch (err) {
      console.error("Base Board (Joaco): no se pudo asignar ids", err);
    } finally {
      this.assigningTaskIds = false;
    }
  }

  // -- Folder rename sync -----------------------------------------------------

  /**
   * When a folder is renamed or moved, rewrite any .base board filter that
   * pointed at the old path so the board keeps working without a manual edit.
   *
   * To avoid race condition, burst of renaming events are collected, and once
   * a timeout is reached we flush and modify the path mappings in .base
   */
  private handleFolderRename(file: TAbstractFile, oldPath: string): void {
    const timeOut = 250;

    // Only folder moves change the folder a filter targets; ignore file renames.
    if (!(file instanceof TFolder)) return;

    const newPath = file.path;
    if (newPath === oldPath) return;

    this.pendingFolderRenames.push({ oldPath, newPath });

    // Debounce: reset the timer on every event so the flush runs only after
    // the rename burst has settled and Obsidian has finished moving files.
    if (this.folderRenameFlushTimer !== null) {
      window.clearTimeout(this.folderRenameFlushTimer);
    }
    this.folderRenameFlushTimer = window.setTimeout(() => {
      this.folderRenameFlushTimer = null;
      void this.flushFolderRenames();
    }, timeOut);
  }

  /** Apply all pending folder-rename mappings to every .base file. */
  private async flushFolderRenames(): Promise<void> {
    const renames = this.pendingFolderRenames;
    this.pendingFolderRenames = [];
    if (renames.length === 0) return;

    const baseFiles = this.app.vault
      .getFiles()
      .filter((f) => f.extension === "base");

    for (const baseFile of baseFiles) {
      try {
        let content = await this.app.vault.read(baseFile);
        let changed = false;
        for (const { oldPath, newPath } of renames) {
          const updated = updateBaseFolderReferences(content, oldPath, newPath);
          if (updated !== null) {
            content = updated;
            changed = true;
          }
        }
        if (changed) {
          await this.app.vault.modify(baseFile, content);
        }
      } catch (err) {
        console.error(
          `Base Board: failed to update folder references in "${baseFile.path}"`,
          err,
        );
      }
    }
  }

  // -- Board scaffolding ------------------------------------------------------

  private async createBoard(config: BoardConfig): Promise<void> {
    const { name, folder, groupBy } = config;
    const vault = this.app.vault;

    // Sanitize folder path
    const safeFolder = folder.replace(/[\\:*?"<>|]/g, "");
    const tasksFolder = `${safeFolder}/Tasks`;

    // 1. Create folder structure
    if (!vault.getAbstractFileByPath(safeFolder)) {
      await vault.createFolder(safeFolder);
    }
    if (!vault.getAbstractFileByPath(tasksFolder)) {
      await vault.createFolder(tasksFolder);
    }

    // 2. Create the .base file
    const basePath = `${safeFolder}/${name}.base`;
    if (vault.getAbstractFileByPath(basePath)) {
      new Notice(`A board already exists at "${basePath}".`);
      return;
    }

    const baseContent = [
      `filters:`,
      `  and:`,
      `    - file.inFolder("${tasksFolder}")`,
      `views:`,
      `  - type: kanban`,
      `    name: ${name}`,
      `    groupBy:`,
      `      property: note.${groupBy}`,
      `      direction: DESC`,
      `    order:`,
      `      - file.name`,
      `      - note.${groupBy}`,
      ``,
    ].join("\n");

    await vault.create(basePath, baseContent);

    // 3. Create sample task files so the board isn't empty on first open
    const sampleTasks = [
      {
        title: "Plan project",
        value: "To Do",
        order: 0,
        tags: ["planning"],
      },
      {
        title: "Research and discovery",
        value: "To Do",
        order: 1,
        tags: ["research"],
      },
      {
        title: "Build first feature",
        value: "In Progress",
        order: 0,
        tags: ["feature"],
      },
      {
        title: "Fix onboarding bug",
        value: "In Progress",
        order: 1,
        tags: ["bug"],
      },
      {
        title: "Write documentation",
        value: "Done",
        order: 0,
        tags: ["docs"],
      },
    ];

    for (const task of sampleTasks) {
      const safeName = sanitizeFilename(task.title);
      const taskPath = `${tasksFolder}/${safeName}.md`;
      if (!vault.getAbstractFileByPath(taskPath)) {
        const tagsLine =
          task.tags.length > 0
            ? `tags:\n${task.tags.map((t) => `  - ${t}`).join("\n")}`
            : "";
        const content = [
          "---",
          `${groupBy}: ${task.value}`,
          `kanban_order: ${task.order}`,
          tagsLine,
          "---",
          "",
          `# ${task.title}`,
          "",
        ]
          .filter((line) => line !== "")
          .join("\n");
        await vault.create(taskPath, content);
      }
    }

    // 4. Open the board
    const file = vault.getAbstractFileByPath(basePath);
    if (file instanceof TFile) {
      void this.app.workspace.getLeaf(false).openFile(file);
      new Notice(`Board "${name}" created!`);
    }
  }

  // -- Card order helpers (Joaco fork) ---------------------------------------

  /** Manual order map for one board (read-only view; do not mutate). */
  getCardOrderMap(baseId: string): OrderMap {
    return this.data_.cardOrders[baseId] ?? {};
  }

  /** Merge order keys for one board and persist data.json once. */
  async setCardOrders(baseId: string, updates: OrderMap): Promise<void> {
    const map = { ...(this.data_.cardOrders[baseId] ?? {}) };
    for (const path of Object.keys(updates)) map[path] = updates[path];
    this.data_.cardOrders[baseId] = map;
    await this.savePluginData();
  }

  private handleCardOrderRename(file: TAbstractFile, oldPath: string): void {
    const isFolder = file instanceof TFolder;
    let changed = false;
    for (const baseId of Object.keys(this.data_.cardOrders)) {
      const map = this.data_.cardOrders[baseId];
      if (renameOrderKeys(map, oldPath, file.path, isFolder)) changed = true;
    }
    if (changed) void this.savePluginData();
  }

  // -- Column config helpers --------------------------------------------------

  getColumnConfig(baseId: string): ColumnConfig | null {
    return this.data_.columnConfigs[baseId] ?? null;
  }

  async saveColumnConfig(baseId: string, config: ColumnConfig): Promise<void> {
    this.data_.columnConfigs[baseId] = config;
    await this.savePluginData();
  }

  // -- Persistence ------------------------------------------------------------

  async loadPluginData(): Promise<void> {
    const saved = (await this.loadData()) as PluginData | null | undefined;
    this.data_ = Object.assign({}, DEFAULT_DATA, saved ?? {});
    if (!this.data_.columnConfigs) this.data_.columnConfigs = {};
    if (!this.data_.cardOrders) this.data_.cardOrders = {};
    this.data_.taskIds = Object.assign(
      {},
      DEFAULT_TASK_IDS,
      this.data_.taskIds ?? {},
    );
  }

  async savePluginData(): Promise<void> {
    await this.saveData(this.data_);
  }
}
