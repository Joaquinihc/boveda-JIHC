/**
 * Estimated-time helpers (Joaco fork).
 *
 * The time property holds a small numeric scale (e.g. 1–5). Cards are
 * sorted by it inside the same priority; missing or non-numeric values
 * always go last, whatever the direction.
 */

/** Parse a frontmatter value into a finite number, or null if unusable. */
export function parseTimeValue(raw: unknown): number | null {
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
  if (typeof raw === "string") {
    const t = raw.trim();
    if (t === "") return null;
    const n = Number(t.replace(",", "."));
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

/** Compare two time values; nulls last; `ascending` = shortest first. */
export function compareTime(
  a: number | null,
  b: number | null,
  ascending: boolean,
): number {
  if (a === null && b === null) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return ascending ? a - b : b - a;
}
