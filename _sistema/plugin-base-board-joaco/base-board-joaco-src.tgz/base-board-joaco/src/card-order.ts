/**
 * Manual card order storage (Joaco fork).
 *
 * Upstream Base Board stores the manual order of each card in the note's
 * frontmatter (`kanban_order`). Writing that property touches the note and
 * resets its modification date, and the first drop into a column rewrote
 * EVERY card in that column. The fork keeps the order in the plugin's own
 * data.json instead, keyed by board id and file path, so reordering cards
 * never modifies a note.
 */

export type OrderMap = Record<string, string | number>;

/**
 * Move order entries when a file or folder is renamed.
 * - File rename: the key `oldPath` becomes `newPath`.
 * - Folder rename: every key under `oldPath/` gets the new prefix.
 * Returns true when the map changed.
 */
export function renameOrderKeys(
  map: OrderMap,
  oldPath: string,
  newPath: string,
  isFolder: boolean,
): boolean {
  let changed = false;
  if (!isFolder) {
    if (Object.prototype.hasOwnProperty.call(map, oldPath)) {
      map[newPath] = map[oldPath];
      delete map[oldPath];
      changed = true;
    }
    return changed;
  }
  const prefix = oldPath.endsWith("/") ? oldPath : `${oldPath}/`;
  const newPrefix = newPath.endsWith("/") ? newPath : `${newPath}/`;
  for (const key of Object.keys(map)) {
    if (key.startsWith(prefix)) {
      map[newPrefix + key.slice(prefix.length)] = map[key];
      delete map[key];
      changed = true;
    }
  }
  return changed;
}

/** Remove the entry of a deleted file. Returns true when the map changed. */
export function deleteOrderKey(map: OrderMap, path: string): boolean {
  if (!Object.prototype.hasOwnProperty.call(map, path)) return false;
  delete map[path];
  return true;
}
