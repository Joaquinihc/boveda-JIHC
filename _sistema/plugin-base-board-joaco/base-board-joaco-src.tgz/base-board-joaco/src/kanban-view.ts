import { parseTimeValue } from "./time-sort";
import { buildSequence } from "./task-id";
import {
  BasesView,
  BasesEntry,
  BasesEntryGroup,
  BasesAllOptions,
  BooleanValue,
  HoverParent,
  HoverPopover,
  NumberValue,
  NullValue,
  QueryController,
  setIcon,
  TFile,
  WorkspaceLeaf,
} from "obsidian";
import type BaseBoardPlugin from "./main";
import { DragDropManager } from "./drag-drop";
import { ColumnManager } from "./column";
import { CardManager } from "./card";
import { Tags } from "./tags";
import {
  compareOrderValues,
  generateOrderKeys,
  isOrderKey,
  OrderValue,
  readOrderValue,
} from "./order";
import { coerceColumnValue, GroupByValueType } from "./value-utils";
import {
  NO_VALUE_COLUMN,
  ORDER_PROPERTY,
  CONFIG_KEY_COLUMNS,
  CONFIG_KEY_COLLAPSED_COLUMNS,
  CONFIG_KEY_OPEN_BEHAVIOR,
  CONFIG_KEY_COLUMN_COLORS,
  CONFIG_KEY_WIP_LIMITS,
  CONFIG_KEY_COVER_PROPERTY,
  CONFIG_KEY_ADD_TO_TOP,
  CONFIG_KEY_SHOW_SUBTASKS,
  CONFIG_KEY_SUBTASKS_HEADING,
  CONFIG_KEY_SUBTASKS_VISIBLE,
  CONFIG_KEY_PRIORITY_PROPERTY,
  CONFIG_KEY_PRIORITY_COLORS,
  CONFIG_KEY_PRIORITY_ORDER,
  CONFIG_KEY_SORT_BY_PRIORITY,
  CONFIG_KEY_TIME_PROPERTY,
  CONFIG_KEY_SORT_BY_TIME,
  CONFIG_KEY_TIME_ASCENDING,
  CONFIG_KEY_SHOW_SEQUENCE,
  CONFIG_KEY_SEQUENCE_COLUMNS,
  DEFAULT_SEQUENCE_COLUMNS,
  CONFIG_KEY_SHOW_ID,
  CONFIG_KEY_ID_PROPERTY,
  DEFAULT_PRIORITY_ORDER,
  CONFIG_KEY_SHOW_FILTER_BAR,
  CONFIG_KEY_FILTER_BAR_PROPERTY,
  CONFIG_KEY_SHOW_MODIFIED,
  DEFAULT_PRIORITY_COLORS,
  CONFIG_KEY_DOUBLE_COLUMNS,
  CONFIG_KEY_DOUBLE_THRESHOLD,
  DEFAULT_DOUBLE_THRESHOLD,
} from "./constants";
import { PropertyFilter } from "./property-filter";
import { isDoubleColumn, parseColumnList } from "./two-col";
import { MasonryLayout } from "./masonry";

interface BoardScrollState {
  boardLeft: number;
  viewTop: number;
  columnTops: Map<string, number>;
}

// ---------------------------------------------------------------------------
//  Kanban View
// ---------------------------------------------------------------------------

/** Joaco fork: Bases view id (must not collide with Obsidian's native "kanban"). */
export const BOARD_VIEW_TYPE = "tablero-joaquin";

export class KanbanView extends BasesView implements HoverParent {
  type = BOARD_VIEW_TYPE;
  // Required by HoverParent — Obsidian manages the popover lifecycle.
  hoverPopover: HoverPopover | null = null;
  scrollEl: HTMLElement;
  containerEl: HTMLElement;
  plugin: BaseBoardPlugin;

  private dragDropManager: DragDropManager;
  private columnManager: ColumnManager;
  public currentGroups: BasesEntryGroup[] = [];
  public cardManager: CardManager;

  /** Prevent re-renders while we batch-update frontmatter. */
  private isUpdating = false;
  /** Track if Bases delivered fresh query data while we were updating. */
  private pendingDataRender = false;
  /** Board-wide card numbers of the last render (Joaco fork, visual only). */
  private sequenceNumbers: Map<string, number> = new Map();
  /** True until the first successful render completes. */
  private isFirstRender = true;
  /** Debounce timer for render calls. */
  private renderTimer: ReturnType<typeof setTimeout> | null = null;
  /** Local drop intent retained until Bases publishes the matching groups. */
  private optimisticMoves = new Map<string, string>();
  private optimisticColumnOrders = new Map<string, string[]>();
  /** Label Manager for tags and filters */
  public tags: Tags;
  /** Permanent property filter bar (Joaco fork). */
  public propertyFilter: PropertyFilter;
  /** Joaco fork: mosaic layout of double columns. */
  public masonry = new MasonryLayout();
  /** Currently selected card file paths (for batch operations) */
  public selectedCards: Set<string> = new Set();
  public detailLeaf: WorkspaceLeaf | null = null;

  constructor(
    controller: QueryController,
    scrollEl: HTMLElement,
    plugin: BaseBoardPlugin,
  ) {
    super(controller);
    this.scrollEl = scrollEl;
    this.plugin = plugin;
    this.containerEl = scrollEl.createDiv({ cls: "base-board-container" });

    this.tags = new Tags(this);
    this.propertyFilter = new PropertyFilter(this);
    this.cardManager = new CardManager(this);
    this.columnManager = new ColumnManager(this);

    this.dragDropManager = new DragDropManager(this.app, {
      onCardDrop: (
        filePath: string,
        targetColumn: string,
        orderedPaths: string[],
      ) => this.handleCardDrop(filePath, targetColumn, orderedPaths),
      onColumnReorder: (orderedNames: string[]) =>
        this.handleColumnReorder(orderedNames),
      getSelectedCards: () => this.selectedCards,
    });
  }

  onload(): void {}

  onunload(): void {
    this.dragDropManager.destroy();
    this.masonry.destroy();
    if (this.renderTimer) window.clearTimeout(this.renderTimer);
  }

  public focus(): void {
    this.containerEl.focus({ preventScroll: true });
  }

  public onDataUpdated(): void {
    if (this.isUpdating) {
      this.pendingDataRender = true;
      return;
    }
    this.acknowledgeOptimisticMoves();
    this.scheduleRender();
  }

  /**
   * Run a batch of state updates without triggering intermediate re-renders.
   * Defers rendering until the entire batch is complete.
   */
  public async applyBatchUpdate(
    updateFn: () => Promise<void> | void,
  ): Promise<void> {
    this.isUpdating = true;
    this.pendingDataRender = false;

    try {
      await updateFn();
    } finally {
      this.isUpdating = false;
    }

    // If Bases fired onDataUpdated during our batch, schedule a debounced render.
    if (this.pendingDataRender) {
      this.pendingDataRender = false;
      this.scheduleRender();
    }
  }

  static getViewOptions(): BasesAllOptions[] {
    return [
      {
        type: "group" as const,
        displayName: "Display",
        items: [
          {
            key: CONFIG_KEY_OPEN_BEHAVIOR,
            type: "dropdown" as const,
            displayName: "Open card in",
            default: "active",
            options: {
              active: "Active pane / tab",
              modal: "Floating modal",
              split: "Split to the right",
              tab: "New tab",
            },
          },
          {
            key: CONFIG_KEY_COVER_PROPERTY,
            type: "text" as const,
            displayName: "Cover property",
            default: "cover",
            placeholder: "E.g. cover",
          },
          {
            key: CONFIG_KEY_ADD_TO_TOP,
            type: "toggle" as const,
            displayName: "Add new cards to top",
            default: false,
          },
          {
            key: CONFIG_KEY_SHOW_MODIFIED,
            type: "toggle" as const,
            displayName: "Mostrar última modificación",
            default: true,
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Subtareas",
        items: [
          {
            key: CONFIG_KEY_SHOW_SUBTASKS,
            type: "toggle" as const,
            displayName: "Mostrar subtareas en las tarjetas",
            default: true,
          },
          {
            key: CONFIG_KEY_SUBTASKS_HEADING,
            type: "text" as const,
            displayName: "Encabezado de la sección",
            default: "Subtareas",
            placeholder: "Subtareas",
          },
          {
            key: CONFIG_KEY_SUBTASKS_VISIBLE,
            type: "slider" as const,
            displayName: "Subtareas visibles por tarjeta",
            default: 5,
            min: 1,
            max: 10,
            step: 1,
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Prioridad",
        items: [
          {
            key: CONFIG_KEY_PRIORITY_PROPERTY,
            type: "property" as const,
            displayName: "Propiedad de prioridad",
            default: "note.prioridad",
            filter: (prop: string) => prop.startsWith("note."),
          },
          {
            key: CONFIG_KEY_PRIORITY_ORDER,
            type: "text" as const,
            displayName: "Orden de valores (mayor a menor)",
            default: DEFAULT_PRIORITY_ORDER,
            placeholder: DEFAULT_PRIORITY_ORDER,
          },
          {
            key: CONFIG_KEY_SORT_BY_PRIORITY,
            type: "toggle" as const,
            displayName: "Ordenar tarjetas por prioridad",
            default: true,
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Tiempo estimado",
        items: [
          {
            key: CONFIG_KEY_TIME_PROPERTY,
            type: "property" as const,
            displayName: "Propiedad de tiempo (numérica)",
            default: "note.tiempo",
            filter: (prop: string) => prop.startsWith("note."),
          },
          {
            key: CONFIG_KEY_SORT_BY_TIME,
            type: "toggle" as const,
            displayName: "Dentro de cada prioridad, ordenar por tiempo",
            default: true,
          },
          {
            key: CONFIG_KEY_TIME_ASCENDING,
            type: "toggle" as const,
            displayName: "Más cortas primero",
            default: true,
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Numeración e id",
        items: [
          {
            key: CONFIG_KEY_SHOW_SEQUENCE,
            type: "toggle" as const,
            displayName: "Numerar las tarjetas (orden de trabajo)",
            default: true,
          },
          {
            key: CONFIG_KEY_SEQUENCE_COLUMNS,
            type: "text" as const,
            displayName: "Columnas a numerar, en orden",
            default: DEFAULT_SEQUENCE_COLUMNS,
            placeholder: DEFAULT_SEQUENCE_COLUMNS,
          },
          {
            key: CONFIG_KEY_SHOW_ID,
            type: "toggle" as const,
            displayName: "Mostrar el id de la tarea",
            default: true,
          },
          {
            key: CONFIG_KEY_ID_PROPERTY,
            type: "property" as const,
            displayName: "Propiedad del id",
            default: "note.id",
            filter: (prop: string) => prop.startsWith("note."),
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Columnas dobles",
        items: [
          {
            key: CONFIG_KEY_DOUBLE_COLUMNS,
            type: "text" as const,
            displayName: "Columnas que se dividen en dos",
            default: "",
            placeholder: "en-curso",
          },
          {
            key: CONFIG_KEY_DOUBLE_THRESHOLD,
            type: "slider" as const,
            displayName: "Dividir cuando tengan más de (tarjetas)",
            default: DEFAULT_DOUBLE_THRESHOLD,
            min: 2,
            max: 30,
            step: 1,
          },
        ],
      },
      {
        type: "group" as const,
        displayName: "Filtro fijo",
        items: [
          {
            key: CONFIG_KEY_SHOW_FILTER_BAR,
            type: "toggle" as const,
            displayName: "Mostrar filtro sobre el tablero",
            default: true,
          },
          {
            key: CONFIG_KEY_FILTER_BAR_PROPERTY,
            type: "property" as const,
            displayName: "Propiedad del filtro",
            default: "note.tipo",
            placeholder: "p. ej. tipo",
            filter: (prop: string) => prop.startsWith("note."),
          },
        ],
      },
    ];
  }

  // ---------------------------------------------------------------------------
  //  Joaco fork: config getters
  // ---------------------------------------------------------------------------

  public isShowSubtasks(): boolean {
    const val = this.config?.get(CONFIG_KEY_SHOW_SUBTASKS);
    return val === undefined || val === null ? true : !!val;
  }

  public getSubtasksHeading(): string {
    const val = this.config?.get(CONFIG_KEY_SUBTASKS_HEADING);
    return typeof val === "string" && val.trim() !== ""
      ? val.trim()
      : "Subtareas";
  }

  public getSubtasksVisible(): number {
    const val = this.config?.get(CONFIG_KEY_SUBTASKS_VISIBLE);
    return typeof val === "number" && val >= 1 ? Math.floor(val) : 5;
  }

  public isShowModified(): boolean {
    const val = this.config?.get(CONFIG_KEY_SHOW_MODIFIED);
    return val === undefined || val === null ? true : !!val;
  }

  /** Frontmatter name of the priority property (without "note."). */
  public getPriorityProperty(): string | null {
    const raw = this.config?.get(CONFIG_KEY_PRIORITY_PROPERTY);
    const val =
      typeof raw === "string" && raw.trim() !== ""
        ? raw.trim()
        : "note.prioridad";
    return val.startsWith("note.") ? val.slice(5) : val;
  }

  public getPriorityColors(): Record<string, string> {
    const raw = this.config?.get(CONFIG_KEY_PRIORITY_COLORS);
    return raw && typeof raw === "object"
      ? (raw as Record<string, string>)
      : {};
  }

  public getPriorityColor(value: string): string | null {
    const key = value.trim().toLowerCase();
    const custom = this.getPriorityColors();
    return custom[key] ?? DEFAULT_PRIORITY_COLORS[key] ?? null;
  }

  public setPriorityColor(value: string, color: string): void {
    const key = value.trim().toLowerCase();
    const colors = this.getPriorityColors();
    if (color) {
      colors[key] = color;
    } else {
      delete colors[key];
    }
    this.config?.set(CONFIG_KEY_PRIORITY_COLORS, colors);
    this.scheduleRender();
  }

  public isSortByPriority(): boolean {
    const val = this.config?.get(CONFIG_KEY_SORT_BY_PRIORITY);
    return val === undefined || val === null ? true : !!val;
  }

  /** Ranking list parsed from the "priorityOrder" option (lowercased). */
  public getPriorityRanking(): string[] {
    const raw = this.config?.get(CONFIG_KEY_PRIORITY_ORDER);
    const text =
      typeof raw === "string" && raw.trim() !== ""
        ? raw
        : DEFAULT_PRIORITY_ORDER;
    return text
      .split(",")
      .map((v) => v.trim().toLowerCase())
      .filter((v) => v !== "");
  }

  /** Rank of a file's priority value; unknown/missing values go last. */
  public getPriorityRank(filePath: string): number {
    const prop = this.getPriorityProperty();
    if (!prop || prop === "__proto__" || prop === "constructor") {
      return Number.MAX_SAFE_INTEGER;
    }
    const file = this.app.vault.getAbstractFileByPath(filePath);
    if (!file || !(file instanceof TFile)) return Number.MAX_SAFE_INTEGER;
    const cache = this.app.metadataCache.getFileCache(file);
    const raw: unknown = cache?.frontmatter?.[prop];
    if (typeof raw !== "string" || raw.trim() === "") {
      return Number.MAX_SAFE_INTEGER;
    }
    const idx = this.getPriorityRanking().indexOf(raw.trim().toLowerCase());
    return idx === -1 ? Number.MAX_SAFE_INTEGER : idx;
  }

  /** Frontmatter name of the estimated-time property (without "note."). */
  public getTimeProperty(): string | null {
    const raw = this.config?.get(CONFIG_KEY_TIME_PROPERTY);
    const val =
      typeof raw === "string" && raw.trim() !== "" ? raw.trim() : "note.tiempo";
    return val.startsWith("note.") ? val.slice(5) : val;
  }

  public isSortByTime(): boolean {
    const val = this.config?.get(CONFIG_KEY_SORT_BY_TIME);
    return val === undefined || val === null ? true : !!val;
  }

  public isTimeAscending(): boolean {
    const val = this.config?.get(CONFIG_KEY_TIME_ASCENDING);
    return val === undefined || val === null ? true : !!val;
  }

  /** Numeric estimated time of a file, or null when missing/non-numeric. */
  public getTimeValue(filePath: string): number | null {
    const prop = this.getTimeProperty();
    if (!prop || prop === "__proto__" || prop === "constructor") return null;
    const file = this.app.vault.getAbstractFileByPath(filePath);
    if (!file || !(file instanceof TFile)) return null;
    const cache = this.app.metadataCache.getFileCache(file);
    return parseTimeValue(cache?.frontmatter?.[prop]);
  }

  public isShowSequence(): boolean {
    const val = this.config?.get(CONFIG_KEY_SHOW_SEQUENCE);
    return val === undefined || val === null ? true : !!val;
  }

  /** Column names to number, in order (lowercased). */
  public getSequenceColumns(): string[] {
    const raw = this.config?.get(CONFIG_KEY_SEQUENCE_COLUMNS);
    const text =
      typeof raw === "string" && raw.trim() !== ""
        ? raw
        : DEFAULT_SEQUENCE_COLUMNS;
    return text
      .split(",")
      .map((v) => v.trim().toLowerCase())
      .filter((v) => v !== "");
  }

  /** Joaco fork: columns configured to split into two when crowded. */
  public getDoubleColumns(): string[] {
    return parseColumnList(this.config?.get(CONFIG_KEY_DOUBLE_COLUMNS));
  }

  /** Joaco fork: visible cards above which a double column splits in two. */
  public getDoubleColumnsThreshold(): number {
    const val = this.config?.get(CONFIG_KEY_DOUBLE_THRESHOLD);
    return typeof val === "number" && val >= 1
      ? Math.floor(val)
      : DEFAULT_DOUBLE_THRESHOLD;
  }

  /** Joaco fork: should this column render its cards in two columns? */
  public isDoubleColumn(columnName: string, visibleCount: number): boolean {
    return isDoubleColumn(
      columnName,
      visibleCount,
      this.getDoubleColumns(),
      this.getDoubleColumnsThreshold(),
    );
  }

  /** Board-wide sequence number of a card, or null (not numbered). */
  public getSequenceNumber(filePath: string): number | null {
    return this.sequenceNumbers.get(filePath) ?? null;
  }

  public isShowTaskId(): boolean {
    const val = this.config?.get(CONFIG_KEY_SHOW_ID);
    return val === undefined || val === null ? true : !!val;
  }

  /** Task id text of a file (e.g. "T-042"), or null when missing. */
  public getTaskIdText(filePath: string): string | null {
    const raw = this.config?.get(CONFIG_KEY_ID_PROPERTY);
    const propId =
      typeof raw === "string" && raw.trim() !== "" ? raw.trim() : "note.id";
    const prop = propId.startsWith("note.") ? propId.slice(5) : propId;
    if (!prop || prop === "__proto__" || prop === "constructor") return null;
    const file = this.app.vault.getAbstractFileByPath(filePath);
    if (!file || !(file instanceof TFile)) return null;
    const val: unknown =
      this.app.metadataCache.getFileCache(file)?.frontmatter?.[prop];
    if (typeof val === "number") return String(val);
    return typeof val === "string" && val.trim() !== "" ? val.trim() : null;
  }

  /**
   * Number every card across the board following the configured column
   * order, using the same sort as the columns. Ignores the tag and property
   * filters on purpose: numbers belong to the whole plan, not to the filter.
   */
  private computeSequenceNumbers(columns: string[]): Map<string, number> {
    if (!this.isShowSequence()) return new Map();
    const cols = columns.map((name) => {
      const group = this.getGroupForColumn(name);
      const entries = this.getEntriesForColumn(name, group);
      const sorted = this.columnManager.sortEntries(name, entries);
      return { name, paths: sorted.map((e) => e.file?.path ?? "") };
    });
    return buildSequence(cols, this.getSequenceColumns());
  }

  /** Raw BasesPropertyId configured for the permanent filter bar, or null. */
  public getFilterBarPropertyId(): string | null {
    const show = this.config?.get(CONFIG_KEY_SHOW_FILTER_BAR);
    if (show !== undefined && show !== null && !show) return null;
    const raw = this.config?.get(CONFIG_KEY_FILTER_BAR_PROPERTY);
    if (raw === undefined || raw === null) return "note.tipo";
    return typeof raw === "string" && raw.trim() !== "" ? raw.trim() : null;
  }

  public isAddNewCardsToTop(): boolean {
    return !!this.config?.get(CONFIG_KEY_ADD_TO_TOP);
  }

  // ---------------------------------------------------------------------------
  //  Base identity
  // ---------------------------------------------------------------------------

  /**
   * Build a stable, unique identifier for this board view.
   *
   * Uses the view's display name (unique within a .base file) combined with
   * the groupBy property.  If neither is available we fall back to a hash
   * derived from the file paths currently in the dataset so that column
   * configs never collide across different boards.
   */
  public getBaseId(): string {
    const viewName = this.config?.name ?? "";
    const groupBy = this.getGroupByProperty() ?? "";

    // Try to discover the .base file path from the entries in the dataset.
    // All entries originate from the same .base query so any entry's folder
    // ancestor pattern is a reasonable proxy.  This gives us a path-qualified
    // key even when two .base files share the same view name.
    let basePath = "";
    const entries: BasesEntry[] = this.data?.data ?? [];
    if (entries.length > 0) {
      const firstPath = entries[0].file?.path ?? "";
      const lastSlash = firstPath.lastIndexOf("/");
      basePath = lastSlash > 0 ? firstPath.substring(0, lastSlash) : "";
    }

    return `${basePath}::${viewName}::${groupBy}`;
  }

  // ---------------------------------------------------------------------------
  //  Helpers
  // ---------------------------------------------------------------------------

  /**
   * Return the frontmatter property name used for groupBy (e.g. "status").
   *
   * The Bases engine stores this in the view config as a BasesPropertyId
   * like "note.status".  We strip the "note." prefix so the result is
   * directly usable as a frontmatter key.
   *
   * Note: `BasesViewConfig.get()` only retrieves custom options registered
   * via `BasesViewRegistration.options`.  The `groupBy` setting is a
   * built-in structural property on the config object, so we access it
   * directly from the config's internal representation.
   */
  public getGroupByProperty(): string | null {
    const cfg = this.config as {
      groupBy?: { property?: string };
      get?: (key: string) => unknown;
    };

    // 1. Direct access to the built-in groupBy config property
    const groupBy = cfg?.groupBy;
    if (groupBy?.property) {
      const raw: string = groupBy.property;
      return raw.startsWith("note.") ? raw.slice(5) : raw;
    }

    // 2. Fallback: try the custom-options API in case future Obsidian
    //    versions surface groupBy through get()
    const fromGet = cfg?.get?.("groupBy") as { property?: string } | undefined;
    if (fromGet?.property) {
      const raw: string = fromGet.property;
      return raw.startsWith("note.") ? raw.slice(5) : raw;
    }

    return null;
  }

  public getCardOpenBehavior(): "active" | "modal" | "split" | "tab" {
    const val = this.config?.get(CONFIG_KEY_OPEN_BEHAVIOR);
    if (val === "modal" || val === "split" || val === "tab") return val;
    return "active";
  }

  public getCardCoverProperty(): string | null {
    const val = this.config?.get(CONFIG_KEY_COVER_PROPERTY);
    if (val === undefined || val === null) {
      return "cover";
    }
    return typeof val === "string" && val.trim() !== "" ? val.trim() : null;
  }

  public isLeafAttached(leaf: WorkspaceLeaf): boolean {
    let found = false;
    this.app.workspace.iterateAllLeaves((l) => {
      if (l === leaf) found = true;
    });
    return found;
  }

  public getColumnColors(): Record<string, string> {
    const raw = this.config?.get(CONFIG_KEY_COLUMN_COLORS);
    return raw && typeof raw === "object"
      ? (raw as Record<string, string>)
      : {};
  }

  public getColumnColor(columnName: string): string | null {
    const customColors = this.getColumnColors();
    return customColors[columnName] ?? null;
  }

  public setColumnColor(columnName: string, color: string): void {
    const colors = this.getColumnColors();
    if (color) {
      colors[columnName] = color;
    } else {
      delete colors[columnName];
    }
    this.config?.set(CONFIG_KEY_COLUMN_COLORS, colors);
    this.scheduleRender();
  }

  // ---------------------------------------------------------------------------
  //  WIP Limits
  // ---------------------------------------------------------------------------

  public getWipLimits(): Record<string, number> {
    const raw = this.config?.get(CONFIG_KEY_WIP_LIMITS);
    return raw && typeof raw === "object"
      ? (raw as Record<string, number>)
      : {};
  }

  public getWipLimit(columnName: string): number | null {
    const limits = this.getWipLimits();
    const val = limits[columnName];
    return typeof val === "number" && val > 0 ? val : null;
  }

  public setWipLimit(columnName: string, limit: number | null): void {
    const limits = this.getWipLimits();
    if (limit !== null && limit > 0) {
      limits[columnName] = limit;
    } else {
      delete limits[columnName];
    }
    this.config?.set(CONFIG_KEY_WIP_LIMITS, limits);
    this.scheduleRender();
  }

  private getColumnName(key: unknown): string {
    if (key === undefined || key === null || key instanceof NullValue) {
      return NO_VALUE_COLUMN;
    }
    if (typeof key === "object" && key !== null) {
      if ("value" in key) {
        const val = (key as Record<string, unknown>).value;
        return String(val);
      }
      // Bases group-key objects expose the column name via toString()
      // eslint-disable-next-line @typescript-eslint/no-base-to-string -- Bases-controlled object with custom toString
      return String(key);
    }
    if (typeof key === "string") return key;
    if (typeof key === "number" || typeof key === "boolean") return String(key);
    return "";
  }

  /**
   * Infer the JS type of the groupBy property from the group keys that Bases
   * actually produced. Bases exposes group keys as typed Value objects, so a
   * checkbox-grouped board yields BooleanValue keys and a numeric one yields
   * NumberValue keys. Booleans win outright so a mix of real checkboxes and
   * already-corrupted "false" strings still resolves to "boolean".
   */
  private groupByValueType(): GroupByValueType {
    for (const group of this.currentGroups) {
      if (group.key instanceof BooleanValue) return "boolean";
      if (group.key instanceof NumberValue) return "number";
    }
    return "other";
  }

  /**
   * Write the groupBy property for a card into `fm`, preserving its real type.
   *
   * The "(No value)" column removes the property entirely; every other column
   * stores a correctly-typed value so a checkbox `false` is never turned into
   * the string "false" (which is truthy and breaks grouping).
   */
  public applyGroupByValue(
    fm: Record<string, unknown>,
    groupByProp: string,
    columnName: string,
  ): void {
    if (columnName === NO_VALUE_COLUMN) {
      delete fm[groupByProp];
      return;
    }
    fm[groupByProp] = coerceColumnValue(columnName, this.groupByValueType());
  }

  /**
   * Manual order of a card. Joaco fork: read from the plugin's data.json
   * first (so reordering never touches notes); fall back to a legacy
   * `kanban_order` frontmatter value if a note still has one.
   */
  public getFileOrder(filePath: string): OrderValue {
    const stored = this.plugin.getCardOrderMap(this.getBaseId())[filePath];
    if (stored !== undefined) return readOrderValue(stored);
    const file = this.app.vault.getAbstractFileByPath(filePath);
    if (!file || !(file instanceof TFile)) return null;
    const cache = this.app.metadataCache.getFileCache(file);
    return readOrderValue(cache?.frontmatter?.[ORDER_PROPERTY]);
  }

  public compareFileOrder(pathA: string, pathB: string): number {
    return compareOrderValues(
      this.getFileOrder(pathA),
      this.getFileOrder(pathB),
    );
  }

  public compareCardOrder(
    columnName: string,
    pathA: string,
    pathB: string,
  ): number {
    const optimisticOrder = this.optimisticColumnOrders.get(columnName);
    if (optimisticOrder) {
      const indexA = optimisticOrder.indexOf(pathA);
      const indexB = optimisticOrder.indexOf(pathB);
      if (indexA !== -1 || indexB !== -1) {
        if (indexA === -1) return 1;
        if (indexB === -1) return -1;
        return indexA - indexB;
      }
    }
    return this.compareFileOrder(pathA, pathB);
  }

  public getEntriesForColumn(
    columnName: string,
    group: BasesEntryGroup | null,
  ): BasesEntry[] {
    const entries = [...(group?.entries ?? [])].filter((entry) => {
      const path = entry.file?.path;
      const optimisticColumn = path ? this.optimisticMoves.get(path) : null;
      return !optimisticColumn || optimisticColumn === columnName;
    });
    const present = new Set(entries.map((entry) => entry.file?.path));

    for (const entry of this.data?.data ?? []) {
      const path = entry.file?.path;
      if (
        path &&
        this.optimisticMoves.get(path) === columnName &&
        !present.has(path)
      ) {
        entries.push(entry);
      }
    }
    return entries;
  }

  public getOrderedPathsForColumn(columnName: string): string[] {
    const group = this.currentGroups.find(
      (candidate) => this.getColumnName(candidate.key) === columnName,
    );
    const paths = (group?.entries ?? [])
      .map((entry) => entry.file?.path)
      .filter((path): path is string => typeof path === "string");
    return paths.sort((a, b) => this.compareFileOrder(a, b));
  }

  // ---------------------------------------------------------------------------
  //  Column config  (dual-layer: .base file via config API + plugin data.json)
  // ---------------------------------------------------------------------------

  /**
   * Read the persisted column order.
   *
   * Priority:
   *  1. View-level config stored inside the .base file (via BasesViewConfig)
   *  2. Legacy plugin data.json (for backwards-compat with existing boards)
   *  3. Fall back to whatever columns the data naturally produces
   *
   * Any columns present in the live data but missing from the stored list
   * are appended at the end so they are never silently hidden.
   */
  public getColumns(): string[] {
    // 1. Try .base file config first (new preferred storage)
    const fromConfig = this.config?.get(CONFIG_KEY_COLUMNS) as
      string[] | undefined;

    // 2. Fallback: legacy plugin data.json
    const fromPlugin = this.plugin.getColumnConfig(this.getBaseId());

    const rawStored = fromConfig?.length
      ? fromConfig
      : fromPlugin?.columns?.length
        ? fromPlugin.columns
        : null;

    const stored = rawStored
      ? rawStored.map((col) => (col === "" ? NO_VALUE_COLUMN : col))
      : null;

    const dataColumns = this.currentGroups.map((g) =>
      this.getColumnName(g.key),
    );

    if (stored && stored.length > 0) {
      const result = [...stored];
      for (const col of dataColumns) {
        if (!result.includes(col)) {
          result.push(col);
        }
      }
      return result;
    }

    return dataColumns;
  }

  public getCollapsedColumns(): Record<string, boolean> {
    const raw = this.config?.get(CONFIG_KEY_COLLAPSED_COLUMNS);
    return raw && typeof raw === "object"
      ? (raw as Record<string, boolean>)
      : {};
  }

  public isColumnCollapsed(columnName: string): boolean {
    return !!this.getCollapsedColumns()[columnName];
  }

  public setColumnCollapsed(columnName: string, collapsed: boolean): void {
    const state = this.getCollapsedColumns();
    if (collapsed) {
      state[columnName] = true;
    } else {
      delete state[columnName];
    }
    this.config?.set(CONFIG_KEY_COLLAPSED_COLUMNS, state);
    this.scheduleRender();
  }

  public toggleColumnCollapsed(columnName: string): void {
    this.setColumnCollapsed(columnName, !this.isColumnCollapsed(columnName));
  }

  private getGroupForColumn(columnName: string): BasesEntryGroup | null {
    for (const group of this.currentGroups) {
      if (this.getColumnName(group.key) === columnName) {
        return group;
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------------
  //  Rendering
  // ---------------------------------------------------------------------------

  /**
   * Ensure `file.name` is present in the view's property `order:` configuration.
   * This guarantees that Obsidian's database engine indexes card titles for search.
   */
  private ensureFileNameInOrder(): void {
    if (!this.config) return;
    const currentOrder =
      (this.config.get("order") as string[] | undefined) ?? [];
    if (
      !currentOrder.includes("file.name") &&
      !currentOrder.includes("file.file")
    ) {
      this.config.set("order", ["file.name", ...currentOrder]);
    }
  }

  public cardElCache = new Map<string, HTMLElement>();
  public columnElCache = new Map<string, HTMLElement>();

  public render(): void {
    this.ensureFileNameInOrder();
    this.selectedCards.clear();
    const scrollState = this.captureScrollState();

    // Index stable DOM nodes before rebuilding the lightweight board shell.
    // Columns are detached as complete subtrees, preserving their card lists,
    // card descendants, scroll state, image elements, and event listeners.
    this.cardElCache.clear();
    this.containerEl.querySelectorAll(".base-board-card").forEach((el) => {
      const path = (el as HTMLElement).dataset.filePath;
      if (path) {
        this.cardElCache.set(path, el as HTMLElement);
      }
    });

    this.columnElCache.clear();
    this.containerEl
      .querySelectorAll<HTMLElement>(".base-board-column")
      .forEach((el) => {
        const name = el.dataset.columnName;
        if (name) {
          this.columnElCache.set(name, el);
          el.remove();
        }
      });

    this.containerEl.empty();

    // Use the official API: this.data is a BasesQueryResult
    const groupedData: BasesEntryGroup[] = this.data?.groupedData ?? [];
    const hasGroupBy =
      groupedData.length > 1 ||
      (groupedData.length === 1 &&
        groupedData[0].key !== undefined &&
        !(groupedData[0].key instanceof NullValue));

    // If the board has configured columns (from .base or data.json) but
    // no cards exist yet, render the empty columns so users can see and
    // add cards instead of showing an opaque placeholder.
    const stored =
      (this.config?.get(CONFIG_KEY_COLUMNS) as string[] | undefined) ??
      this.plugin.getColumnConfig(this.getBaseId())?.columns;
    const hasStoredColumns = stored && stored.length > 0;
    const shouldShowPlaceholder =
      !hasGroupBy && groupedData.length <= 1 && !hasStoredColumns;

    if (shouldShowPlaceholder) {
      const msgEl = this.containerEl.createDiv({
        cls: "base-board-placeholder",
      });
      setIcon(
        msgEl.createSpan({ cls: "base-board-placeholder-icon" }),
        "lucide-kanban",
      );
      msgEl.createEl("p", {
        text: 'Set "group by" in the sort menu to organize cards into columns.',
      });
      return;
    }

    this.currentGroups = groupedData;
    const columns = this.getColumns();
    this.sequenceNumbers = this.computeSequenceNumbers(columns);
    const boardEl = this.containerEl.createDiv({ cls: "base-board-board" });

    // Only animate cards on the very first render
    if (this.isFirstRender) {
      boardEl.addClass("base-board-board--animate");
      this.isFirstRender = false;
    }

    this.tags.renderFilterBar(this.containerEl);
    this.propertyFilter.renderFilterBar(this.containerEl);

    columns.forEach((columnName, idx) => {
      const group = this.getGroupForColumn(columnName);
      this.columnManager.renderColumn(
        boardEl,
        columnName,
        group,
        idx,
        this.columnElCache.get(columnName),
      );
    });

    this.columnManager.renderAddColumnButton(boardEl);
    this.dragDropManager.initBoard(boardEl);
    this.restoreScrollState(boardEl, scrollState);
  }

  private captureScrollState(): BoardScrollState {
    const boardEl =
      this.containerEl.querySelector<HTMLElement>(".base-board-board");
    const columnTops = new Map<string, number>();

    boardEl
      ?.querySelectorAll<HTMLElement>(".base-board-column")
      .forEach((columnEl) => {
        const name = columnEl.dataset.columnName;
        const cardsEl =
          columnEl.querySelector<HTMLElement>(".base-board-cards");
        if (name && cardsEl) columnTops.set(name, cardsEl.scrollTop);
      });

    return {
      boardLeft: boardEl?.scrollLeft ?? 0,
      viewTop: this.scrollEl.scrollTop,
      columnTops,
    };
  }

  private restoreScrollState(
    boardEl: HTMLElement,
    state: BoardScrollState,
  ): void {
    // All columns are attached, so these assignments restore against the final
    // layout and cannot race a deferred callback from an earlier render.
    boardEl.scrollLeft = state.boardLeft;
    this.scrollEl.scrollTop = state.viewTop;

    boardEl
      .querySelectorAll<HTMLElement>(".base-board-column")
      .forEach((columnEl) => {
        const name = columnEl.dataset.columnName;
        const cardsEl =
          columnEl.querySelector<HTMLElement>(".base-board-cards");
        const scrollTop = name ? state.columnTops.get(name) : undefined;
        if (cardsEl && scrollTop !== undefined) {
          cardsEl.scrollTop = scrollTop;
        }
      });
  }

  // ---------------------------------------------------------------------------
  //  Column & Filter management helpers
  // ---------------------------------------------------------------------------

  private handleColumnReorder(orderedNames: string[]): void {
    this.saveColumns(orderedNames);
    this.render();
  }

  /**
   * Persist the column list.
   *
   * Writes to two locations for compatibility:
   *  - BasesViewConfig (stored inside the .base file itself — portable)
   *  - Plugin data.json (legacy, kept so older board setups still work)
   */
  public saveColumns(columns: string[]): void {
    // Primary: persist in .base file via the official config API
    const toSave = columns.map((col) => (col === NO_VALUE_COLUMN ? "" : col));
    this.config?.set(CONFIG_KEY_COLUMNS, toSave);

    // Legacy fallback: also write to plugin data.json
    void this.plugin.saveColumnConfig(this.getBaseId(), { columns });
  }

  public updateColumnPreferences(oldName: string, newName: string): void {
    const collapsed = this.getCollapsedColumns();
    if (collapsed[oldName]) {
      delete collapsed[oldName];
      collapsed[newName] = true;
      this.config?.set(CONFIG_KEY_COLLAPSED_COLUMNS, collapsed);
    }
  }

  public removeColumnPreferences(columnName: string): void {
    const collapsed = this.getCollapsedColumns();
    if (collapsed[columnName]) {
      delete collapsed[columnName];
      this.config?.set(CONFIG_KEY_COLLAPSED_COLUMNS, collapsed);
    }
  }

  // ---------------------------------------------------------------------------
  //  Card drop handler (column move + reordering)
  // ---------------------------------------------------------------------------

  private async handleCardDrop(
    filePath: string,
    targetColumnName: string,
    orderedPaths: string[],
  ): Promise<void> {
    const groupByProp = this.getGroupByProperty();
    if (!groupByProp) {
      throw new Error("Cannot move a card without a group by property");
    }

    // Snapshot the selection NOW, before any async work or re-render can clear it
    const selectedSnapshot = new Set(this.selectedCards);
    const isMultiDrag =
      selectedSnapshot.size > 1 && selectedSnapshot.has(filePath);

    // If the dragged card is part of a multi-selection, expand the drop to
    // include all selected cards. The dragged card goes where it was dropped
    // (already in orderedPaths); the rest of the selection is appended after.
    const otherSelected = isMultiDrag
      ? Array.from(selectedSnapshot).filter(
          (p) => p !== filePath && !orderedPaths.includes(p),
        )
      : [];

    // Insert co-selected cards right after the dragged card's position
    const fullOrderedPaths = [...orderedPaths];
    if (otherSelected.length > 0) {
      const dropIdx = fullOrderedPaths.indexOf(filePath);
      const insertAt = dropIdx !== -1 ? dropIdx + 1 : fullOrderedPaths.length;
      fullOrderedPaths.splice(insertAt, 0, ...otherSelected);
    }

    const pathsToMove = isMultiDrag ? [filePath, ...otherSelected] : [filePath];
    for (const path of pathsToMove) {
      this.optimisticMoves.set(path, targetColumnName);
    }
    this.optimisticColumnOrders.set(targetColumnName, fullOrderedPaths);

    try {
      await this.applyBatchUpdate(async () => {
        // 1. Move all cards to the target column (dragged card + any co-selected)
        const movePromises = pathsToMove.map((fp) => {
          const file = this.app.vault.getAbstractFileByPath(fp);
          if (!file || !(file instanceof TFile)) return Promise.resolve();
          const sourceColumn = this.getCardSourceColumn(fp);
          if (sourceColumn === targetColumnName) return Promise.resolve();
          return this.app.fileManager.processFrontMatter(
            file,
            (fm: Record<string, unknown>) => {
              this.applyGroupByValue(fm, groupByProp, targetColumnName);
            },
          );
        });
        await Promise.all(movePromises);

        // 2. Update only the moved cards when the column already uses string
        // fractional keys. Numeric legacy columns are migrated once, in DOM order.
        await this.writeCardOrder(fullOrderedPaths, pathsToMove);
      });
    } catch (error) {
      this.clearOptimisticMoves(pathsToMove, targetColumnName);
      this.scheduleRender();
      throw error;
    }

    // The optimistic DOM move remains visible until Bases acknowledges the
    // write through onDataUpdated(), which is the only fresh-data render path.
  }

  private acknowledgeOptimisticMoves(): void {
    const confirmedPaths: string[] = [];
    for (const [path, expectedColumn] of this.optimisticMoves) {
      if (
        this.findCardColumn(this.data?.groupedData ?? [], path) ===
        expectedColumn
      ) {
        confirmedPaths.push(path);
      }
    }
    for (const path of confirmedPaths) this.optimisticMoves.delete(path);

    for (const [columnName, orderedPaths] of this.optimisticColumnOrders) {
      if (orderedPaths.every((path) => !this.optimisticMoves.has(path))) {
        this.optimisticColumnOrders.delete(columnName);
      }
    }
  }

  private clearOptimisticMoves(paths: string[], columnName: string): void {
    for (const path of paths) this.optimisticMoves.delete(path);
    this.optimisticColumnOrders.delete(columnName);
  }

  /** Persist a contiguous block within an ordered column. */
  public async writeCardOrder(
    orderedPaths: string[],
    pathsToAssign: string[],
  ): Promise<void> {
    if (pathsToAssign.length === 0) return;

    const startIdx = orderedPaths.indexOf(pathsToAssign[0]);
    const prevPath = startIdx > 0 ? orderedPaths[startIdx - 1] : null;
    const nextPath =
      startIdx + pathsToAssign.length < orderedPaths.length
        ? orderedPaths[startIdx + pathsToAssign.length]
        : null;
    const existingPaths = orderedPaths.filter(
      (path) => !pathsToAssign.includes(path),
    );
    const hasLegacyOrder = existingPaths.some(
      (path) => !isOrderKey(this.getFileOrder(path)),
    );
    const pathsToWrite = hasLegacyOrder ? orderedPaths : pathsToAssign;
    const previousOrder = prevPath ? this.getFileOrder(prevPath) : null;
    const followingOrder = nextPath ? this.getFileOrder(nextPath) : null;
    const newOrders = hasLegacyOrder
      ? generateOrderKeys(null, null, orderedPaths.length)
      : generateOrderKeys(
          isOrderKey(previousOrder) ? previousOrder : null,
          isOrderKey(followingOrder) ? followingOrder : null,
          pathsToAssign.length,
        );

    // Joaco fork: persist the order in data.json, never in the notes, so a
    // drop does not change any note's modification date.
    const updates: Record<string, string> = {};
    pathsToWrite.forEach((cardPath, index) => {
      updates[cardPath] = hasLegacyOrder
        ? newOrders[index]
        : newOrders[pathsToAssign.indexOf(cardPath)];
    });
    await this.plugin.setCardOrders(this.getBaseId(), updates);
    this.scheduleRender();
  }

  /** Joaco fork: store the order of a single (e.g. newly created) card. */
  public async setCardOrder(
    filePath: string,
    order: OrderValue,
  ): Promise<void> {
    if (order === null) return;
    await this.plugin.setCardOrders(this.getBaseId(), { [filePath]: order });
  }

  /** Debounced render — coalesces multiple calls into one. */
  public scheduleRender(): void {
    if (this.renderTimer) window.clearTimeout(this.renderTimer);
    this.renderTimer = window.setTimeout(() => {
      this.renderTimer = null;
      this.render();
    }, 50);
  }

  private getCardSourceColumn(filePath: string): string | null {
    return this.findCardColumn(this.currentGroups, filePath);
  }

  private findCardColumn(
    groups: BasesEntryGroup[],
    filePath: string,
  ): string | null {
    for (const group of groups) {
      for (const entry of group.entries) {
        if (entry.file?.path === filePath) {
          return this.getColumnName(group.key);
        }
      }
    }
    return null;
  }
}
