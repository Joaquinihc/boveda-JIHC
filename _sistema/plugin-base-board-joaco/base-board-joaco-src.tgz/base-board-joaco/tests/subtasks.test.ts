import { describe, it, expect } from "vitest";
import { parseSubtasks } from "../src/subtasks";

const NOTE = `---
type: tarea
estado: pendiente
---

# Restructurar P&L

## Subtareas
- [ ] Definir estructura nueva
- [x] Reunión con Pablo
- [ ] Mapear cuentas Odoo
- [ ]

## Notas
- [ ] esto no es una subtarea (otra sección)
`;

describe("parseSubtasks", () => {
  it("extracts only the checkboxes under the configured heading", () => {
    const tasks = parseSubtasks(NOTE, "Subtareas");
    expect(tasks.map((t) => t.text)).toEqual([
      "Definir estructura nueva",
      "Reunión con Pablo",
      "Mapear cuentas Odoo",
    ]);
    expect(tasks.map((t) => t.done)).toEqual([false, true, false]);
  });

  it("is case-insensitive on the heading and skips empty items", () => {
    const tasks = parseSubtasks(NOTE, "subtareas");
    expect(tasks).toHaveLength(3);
  });

  it("returns empty when the section does not exist", () => {
    expect(parseSubtasks(NOTE, "Checklist")).toEqual([]);
  });

  it("stops at the next heading of any level", () => {
    const note = "## Subtareas\n- [ ] a\n### Sub-sección\n- [ ] b\n";
    const tasks = parseSubtasks(note, "Subtareas");
    expect(tasks.map((t) => t.text)).toEqual(["a"]);
  });

  it("records line numbers usable for toggling", () => {
    const tasks = parseSubtasks(NOTE, "Subtareas");
    const lines = NOTE.split("\n");
    for (const t of tasks) {
      expect(lines[t.lineNo]).toContain(t.text);
    }
  });
});
