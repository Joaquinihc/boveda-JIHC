import { BasesPropertyId, NullValue, setIcon, setTooltip } from "obsidian";
import { KanbanView } from "./kanban-view";
import { CONFIG_KEY_FILTER_BAR_SELECTED } from "./constants";

/**
 * Permanent filter bar over the board for one frontmatter property
 * (e.g. "tipo"). Unlike the tag filter bar, it is always visible while a
 * property is configured, and the selection is persisted in the .base file
 * so it survives closing and reopening the board.
 */
export class PropertyFilter {
  private view: KanbanView;

  constructor(view: KanbanView) {
    this.view = view;
  }

  /** Frontmatter property name (without "note.") or null when disabled. */
  public getPropertyName(): string | null {
    const raw = this.view.getFilterBarPropertyId();
    if (!raw) return null;
    return raw.startsWith("note.") ? raw.slice(5) : raw;
  }

  public getSelected(): Set<string> {
    const raw = this.view.config?.get(CONFIG_KEY_FILTER_BAR_SELECTED);
    return new Set(
      Array.isArray(raw)
        ? raw.filter((v): v is string => typeof v === "string")
        : [],
    );
  }

  private setSelected(values: Set<string>): void {
    this.view.config?.set(CONFIG_KEY_FILTER_BAR_SELECTED, Array.from(values));
    this.view.scheduleRender();
  }

  /** Value of the filtered property for one file path ("" when missing). */
  public getValueForPath(filePath: string): string {
    const propName = this.getPropertyName();
    if (!propName || propName === "__proto__" || propName === "constructor") {
      return "";
    }
    const file = this.view.app.vault.getAbstractFileByPath(filePath);
    if (!file) return "";
    const cache = this.view.app.metadataCache.getFileCache(
      file as import("obsidian").TFile,
    );
    const raw: unknown = cache?.frontmatter?.[propName];
    return this.stringify(raw);
  }

  private stringify(raw: unknown): string {
    if (raw === undefined || raw === null) return "";
    if (typeof raw === "string") return raw;
    if (typeof raw === "number" || typeof raw === "boolean") {
      return String(raw);
    }
    if (Array.isArray(raw)) {
      return raw.map((v) => this.stringify(v)).join(", ");
    }
    return "";
  }

  /** True when the card passes the current property filter. */
  public passes(filePath: string): boolean {
    const selected = this.getSelected();
    if (selected.size === 0) return true;
    return selected.has(this.getValueForPath(filePath));
  }

  public renderFilterBar(container: HTMLElement): void {
    const propName = this.getPropertyName();
    if (!propName) return;

    const boardEl = container.querySelector(".base-board-board");
    if (!boardEl) return;

    // Collect distinct values across the full (unfiltered) dataset
    const values = new Set<string>();
    const propId = `note.${propName}` as BasesPropertyId;
    for (const entry of this.view.data?.data ?? []) {
      const val = entry.getValue(propId);
      if (!val || val instanceof NullValue || !val.isTruthy()) continue;
      const display = val.toString().trim();
      if (display) values.add(display);
    }

    const selected = this.getSelected();
    // Keep stale selections visible so they can be un-selected
    for (const sel of selected) values.add(sel);

    const barEl = container.createDiv({ cls: "base-board-prop-filter-bar" });
    container.insertBefore(barEl, boardEl);

    const titleEl = barEl.createSpan({
      cls: "base-board-filter-title",
      text: `${propName}:`,
    });
    setIcon(titleEl, "lucide-filter");

    for (const value of Array.from(values).sort()) {
      const pill = barEl.createSpan({ cls: "base-board-prop-filter-pill" });
      pill.textContent = value;
      if (selected.has(value)) pill.addClass("is-active");
      setTooltip(pill, `Filtrar por ${propName} = ${value}`);
      pill.addEventListener("click", () => {
        const next = this.getSelected();
        if (next.has(value)) {
          next.delete(value);
        } else {
          next.add(value);
        }
        this.setSelected(next);
      });
    }

    if (selected.size > 0) {
      const clearBtn = barEl.createSpan({
        cls: "base-board-filter-clear",
        text: "Limpiar",
      });
      clearBtn.addEventListener("click", () => {
        this.setSelected(new Set());
      });
    }
  }
}
