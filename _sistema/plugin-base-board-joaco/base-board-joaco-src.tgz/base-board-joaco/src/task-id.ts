/**
 * Task ids and board sequence numbers (Joaco fork).
 *
 * - Task id: a stable, never-reused code stored in each task's frontmatter
 *   (e.g. "T-042"). New tasks get max+1, ordered by their `creado` date.
 * - Sequence number: a purely visual position (1, 2, 3…) computed at render
 *   time across columns in a configured order. Never stored anywhere.
 */

/** Parse "T-042" / "t-42" / 42 into 42 (for the given prefix); null otherwise. */
export function parseTaskId(raw: unknown, prefix: string): number | null {
  if (typeof raw === "number") {
    return Number.isInteger(raw) && raw > 0 ? raw : null;
  }
  if (typeof raw !== "string") return null;
  const t = raw.trim();
  if (t === "") return null;
  const p = prefix.trim().toLowerCase();
  const body = p && t.toLowerCase().startsWith(p) ? t.slice(p.length) : t;
  if (!/^\d+$/.test(body)) return null;
  const n = parseInt(body, 10);
  return n > 0 ? n : null;
}

/** Format 42 as "T-042" (pad = minimum digits). */
export function formatTaskId(n: number, prefix: string, pad: number): string {
  let digits = String(n);
  while (digits.length < pad) digits = "0" + digits;
  return `${prefix}${digits}`;
}

export interface IdCandidate {
  path: string;
  /** `creado` as YYYY-MM-DD (or null when missing/invalid). */
  creado: string | null;
  /** File creation time (ms), used as fallback and tie-breaker. */
  ctime: number;
}

/** Normalize a frontmatter date value to YYYY-MM-DD, or null. */
export function normalizeDate(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const m = raw.trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : null;
}

function isoDay(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

/**
 * Plan ids for tasks without one: next numbers after the current max,
 * oldest `creado` first (ctime when missing), then ctime, then path.
 */
export function planIdAssignments(
  existing: number[],
  candidates: IdCandidate[],
  prefix: string,
  pad: number,
): Array<{ path: string; id: string }> {
  let next = existing.reduce((m, n) => (n > m ? n : m), 0) + 1;
  const sorted = [...candidates].sort((a, b) => {
    const da = a.creado ?? isoDay(a.ctime);
    const db = b.creado ?? isoDay(b.ctime);
    if (da !== db) return da < db ? -1 : 1;
    if (a.ctime !== b.ctime) return a.ctime - b.ctime;
    return a.path.localeCompare(b.path);
  });
  return sorted.map((c) => ({
    path: c.path,
    id: formatTaskId(next++, prefix, pad),
  }));
}

/**
 * Global sequence numbers: walk the columns in `sequence` order (matched
 * case-insensitively) and number their already-sorted paths 1, 2, 3…
 * Columns not listed in `sequence` get no number.
 */
export function buildSequence(
  columns: Array<{ name: string; paths: string[] }>,
  sequence: string[],
): Map<string, number> {
  const byName = new Map<string, string[]>();
  for (const c of columns) byName.set(c.name.trim().toLowerCase(), c.paths);
  const out = new Map<string, number>();
  let n = 1;
  for (const name of sequence) {
    const paths = byName.get(name.trim().toLowerCase());
    if (!paths) continue;
    for (const p of paths) {
      if (!out.has(p)) out.set(p, n++);
    }
  }
  return out;
}
