import { describe, it, expect } from "vitest";
import {
  parseTaskId,
  formatTaskId,
  normalizeDate,
  planIdAssignments,
  buildSequence,
} from "../src/task-id";

describe("parseTaskId / formatTaskId", () => {
  it("parses ids with or without prefix and padding", () => {
    expect(parseTaskId("T-042", "T-")).toBe(42);
    expect(parseTaskId("t-7", "T-")).toBe(7);
    expect(parseTaskId("15", "T-")).toBe(15);
    expect(parseTaskId(3, "T-")).toBe(3);
  });
  it("rejects anything else", () => {
    expect(parseTaskId("", "T-")).toBeNull();
    expect(parseTaskId("T-", "T-")).toBeNull();
    expect(parseTaskId("T-0", "T-")).toBeNull();
    expect(parseTaskId("X-12", "T-")).toBeNull();
    expect(parseTaskId(null, "T-")).toBeNull();
    expect(parseTaskId(1.5, "T-")).toBeNull();
  });
  it("formats with padding", () => {
    expect(formatTaskId(7, "T-", 3)).toBe("T-007");
    expect(formatTaskId(1234, "T-", 3)).toBe("T-1234");
  });
});

describe("normalizeDate", () => {
  it("keeps the YYYY-MM-DD part", () => {
    expect(normalizeDate("2026-09-15")).toBe("2026-09-15");
    expect(normalizeDate("2026-09-15T10:00")).toBe("2026-09-15");
    expect(normalizeDate("{{date}}")).toBeNull();
    expect(normalizeDate(undefined)).toBeNull();
  });
});

describe("planIdAssignments", () => {
  it("continues after the max existing id, oldest creado first", () => {
    const plan = planIdAssignments(
      [1, 5, 3],
      [
        { path: "Tareas/B.md", creado: "2026-09-20", ctime: 10 },
        { path: "Tareas/A.md", creado: "2026-09-10", ctime: 20 },
        { path: "Tareas/C.md", creado: "2026-09-20", ctime: 5 },
      ],
      "T-",
      3,
    );
    expect(plan).toEqual([
      { path: "Tareas/A.md", id: "T-006" },
      { path: "Tareas/C.md", id: "T-007" },
      { path: "Tareas/B.md", id: "T-008" },
    ]);
  });
  it("starts at 1 when there are no ids and uses ctime when creado is missing", () => {
    const day = Date.UTC(2026, 8, 1);
    const plan = planIdAssignments(
      [],
      [
        { path: "Tareas/X.md", creado: null, ctime: day },
        { path: "Tareas/Y.md", creado: "2026-08-15", ctime: day + 1 },
      ],
      "T-",
      3,
    );
    expect(plan.map((p) => p.id)).toEqual(["T-001", "T-002"]);
    expect(plan[0].path).toBe("Tareas/Y.md");
  });
});

describe("buildSequence", () => {
  const cols = [
    { name: "propuesta", paths: ["p1"] },
    { name: "pendiente", paths: ["q1", "q2"] },
    { name: "en-curso", paths: ["c1"] },
    { name: "en-revision", paths: ["r1", "r2"] },
    { name: "hecho", paths: ["h1"] },
  ];
  it("numbers columns in the configured order and skips unlisted ones", () => {
    const seq = buildSequence(cols, [
      "en-revision",
      "en-curso",
      "pendiente",
      "bloqueada",
      "propuesta",
    ]);
    expect([...seq.entries()]).toEqual([
      ["r1", 1],
      ["r2", 2],
      ["c1", 3],
      ["q1", 4],
      ["q2", 5],
      ["p1", 6],
    ]);
    expect(seq.has("h1")).toBe(false);
  });
  it("matches column names case-insensitively", () => {
    const seq = buildSequence(
      [{ name: "En-Revision", paths: ["a"] }],
      ["en-revision"],
    );
    expect(seq.get("a")).toBe(1);
  });
});
