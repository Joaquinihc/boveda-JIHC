// Joaco fork: crowded columns (e.g. "en-curso") switch to a two-column grid
// that reads in zigzag (row by row: 1 | 2, 3 | 4, …).

/** Screen box of a card (subset of DOMRect, so tests can use plain objects). */
export interface CardBox {
  top: number;
  bottom: number;
  left: number;
  right: number;
}

/** Parse a comma-separated list of column names (lower-cased, trimmed). */
export function parseColumnList(raw: unknown): string[] {
  if (typeof raw !== "string") return [];
  return raw
    .split(",")
    .map((v) => v.trim().toLowerCase())
    .filter((v) => v !== "");
}

/** True when the column is configured as double and has more than `threshold` visible cards. */
export function isDoubleColumn(
  columnName: string,
  visibleCount: number,
  columns: string[],
  threshold: number,
): boolean {
  if (columns.length === 0) return false;
  if (!columns.includes(columnName.trim().toLowerCase())) return false;
  return visibleCount > threshold;
}

/** Default vertical gap between cards in the mosaic (matches the CSS gap). */
export const MASONRY_GAP = 6;

/**
 * Number of 1px grid rows a card spans in the mosaic layout: its height plus
 * the gap below it, rounded up.
 */
export function masonrySpan(height: number, gap = MASONRY_GAP): number {
  const h = Number.isFinite(height) && height > 0 ? height : 0;
  return Math.max(1, Math.ceil(h + gap));
}

/**
 * Where a dragged card should be inserted in the two-column mosaic, given the
 * cursor position. Boxes must be in DOM order. The cursor picks a half (the one
 * under it, or the nearest); inside that half the card goes before the first
 * card whose vertical center is below the cursor, or right after the last card
 * of that half. Returns the index of the card to insert before, or -1 to
 * append at the end.
 */
export function masonryInsertIndex(
  boxes: CardBox[],
  x: number,
  y: number,
  tolerance = 4,
): number {
  if (boxes.length === 0) return -1;
  interface Half {
    left: number;
    right: number;
    indices: number[];
  }
  const halves: Half[] = [];
  boxes.forEach((box, i) => {
    const half = halves.find((h) => Math.abs(h.left - box.left) <= tolerance);
    if (half) {
      half.indices.push(i);
      half.right = Math.max(half.right, box.right);
    } else {
      halves.push({ left: box.left, right: box.right, indices: [i] });
    }
  });

  const center = (h: Half) => (h.left + h.right) / 2;
  let half = halves.find((h) => x >= h.left && x <= h.right);
  if (!half) {
    half = halves.reduce((best, h) =>
      Math.abs(center(h) - x) < Math.abs(center(best) - x) ? h : best,
    );
  }

  for (const i of half.indices) {
    const box = boxes[i];
    if (y < (box.top + box.bottom) / 2) return i;
  }
  const last = half.indices[half.indices.length - 1];
  return last + 1 < boxes.length ? last + 1 : -1;
}
